import java.util.Set;
import java.util.TreeSet;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.HashSet;

/**
 * This utility class is not meant to be instantitated, and just provides some
 * useful methods on FD sets.
 * 
 * @author Charlie Dahle
 * @version 10/25/22
 */
public final class FDUtil {

  /**
   * Resolves all trivial FDs in the given set of FDs
   * 
   * @param fdset (Immutable) FD Set
   * @return a set of trivial FDs with respect to the given FDSet
   */
  public static FDSet trivial(final FDSet fdset) {

    FDSet toReturn = new FDSet();

    for (FD f : fdset) {
      Set<Set<String>> powerSet = FDUtil.powerSet(f.getLeft());
      for (Set<String> subSet : powerSet) {
        if (!subSet.isEmpty()) {
          toReturn.add(new FD(f.getLeft(), subSet));
        }
      }
    }
    return toReturn;
  }

  /**
   * Augments every FD in the given set of FDs with the given attributes
   * 
   * @param fdset FD Set (Immutable)
   * @param attrs a set of attributes with which to augment FDs (Immutable)
   * @return a set of augmented FDs
   */
  public static FDSet augment(final FDSet fdset, final Set<String> attrs) {

    FDSet newSet = new FDSet();

    for (FD f : fdset) {
      FD copy = new FD(f);
      copy.addToLeft(attrs);
      copy.addToRight(attrs);
      newSet.add(copy);
    }
    return newSet;
  }

  /**
   * Exhaustively resolves transitive FDs with respect to the given set of FDs
   * 
   * @param fdset (Immutable) FD Set
   * @return all transitive FDs with respect to the input FD set
   */
  public static FDSet transitive(final FDSet fdset) {

    FDSet total = new FDSet(fdset);
    FDSet discovered = new FDSet();
    Boolean changed = true;

    while (changed) {
      changed = false;
      for (FD f : total) {
        for (FD d : total) {
          if (f.getRight().equals(d.getLeft()) && !discovered.getSet().contains(new FD(f.getLeft(), d.getRight()))) {
            discovered.add(new FD(f.getLeft(), d.getRight()));
            changed = true;
          }
        }
      }
      total.addAll(discovered);
    }
    return total;
  }

  /**
   * Generates the closure of the given FD Set
   * 
   * @param fdset (Immutable) FD Set
   * @return the closure of the input FD Set
   */
  public static FDSet fdSetClosure(final FDSet fdset) {
    FDSet copy = new FDSet(fdset);
    Boolean changed = true;
    int oldSize = fdset.size();

    while (changed) {

      oldSize = copy.size();
      Set<String> attrs = new HashSet<>();

      copy.addAll(trivial(copy));

      for (FD f : copy) {

        if (f.getLeft().size() == 1) {
          attrs.addAll(f.getLeft());
        } else {
          attrs.addAll(f.getLeft());
        }
        attrs.addAll(f.getRight());
      }

      // System.out.println("Attrs: " + attrs);
      // TODO Find power set of attrs, then loop through all elements in the powerset,
      // and call augment on each one

      Set<Set<String>> pwrSet = FDUtil.powerSet(attrs);

      for (Set<String> s : pwrSet) {
        copy.addAll(FDUtil.augment(copy, s));
      }

      copy.addAll(FDUtil.transitive(copy));

      if (oldSize == copy.size()) {
        changed = false;
      }
    }
    return copy;
  }

  /**
   * Generates the power set of the given set (that is, all subsets of the given
   * set of elements)
   * 
   * @param set Any set of elements (Immutable)
   * @return the power set of the input set
   */
  @SuppressWarnings("unchecked")
  public static <E> Set<Set<E>> powerSet(final Set<E> set) {

    // base case: power set of the empty set is the set containing the empty set
    if (set.size() == 0) {
      Set<Set<E>> basePset = new HashSet();
      basePset.add(new HashSet<>());
      return basePset;
    }

    // remove the first element from the current set
    E[] attrs = (E[]) set.toArray();
    set.remove(attrs[0]);

    // recurse and obtain the power set of the reduced set of elements
    Set<Set<E>> currentPset = FDUtil.powerSet(set);

    // restore the element from input set
    set.add(attrs[0]);

    // iterate through all elements of current power set and union with first
    // element
    Set<Set<E>> otherPset = new HashSet<>();
    for (Set<E> attrSet : currentPset) {
      Set<E> otherAttrSet = new HashSet<>(attrSet);
      otherAttrSet.add(attrs[0]);
      otherPset.add(otherAttrSet);
    }
    currentPset.addAll(otherPset);
    return currentPset;
  }
}